/* VÓRTICE · Interacciones y EmailJS opcional
   - Menú móvil
   - Scrollspy
   - Lightbox
   - Back-to-top
   - Form con EmailJS (si config.useEmailJS === true)
*/
const navToggle = document.querySelector('.nav-toggle');
const menu = document.getElementById('menu');
navToggle?.addEventListener('click', () => {
  const open = navToggle.getAttribute('aria-expanded') === 'true';
  navToggle.setAttribute('aria-expanded', String(!open));
  menu.style.display = open ? 'none' : 'flex';
});

// Scrollspy simple
const links = Array.from(document.querySelectorAll('.menu a'));
const sections = links.map(a => document.querySelector(a.getAttribute('href'))).filter(Boolean);
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    const idx = sections.indexOf(entry.target);
    if (idx >= 0 && entry.isIntersecting){
      links.forEach(l => l.classList.remove('is-active'));
      links[idx].classList.add('is-active');
    }
  });
}, { rootMargin: "-50% 0px -40% 0px", threshold: 0.01});
sections.forEach(sec => observer.observe(sec));

// Back to top
const backToTop = document.querySelector('.back-to-top');
const backObs = new IntersectionObserver((entries)=>{
  entries.forEach(e=>{
    backToTop?.classList.toggle('is-visible', !e.isIntersecting);
  });
}, {threshold:0});
backObs.observe(document.querySelector('#portada'));

// Lightbox minimalista
document.addEventListener('click', (e) => {
  const a = e.target.closest('a[data-lightbox]');
  if(!a) return;
  e.preventDefault();
  const src = a.getAttribute('href');
  const overlay = document.createElement('div');
  overlay.style.cssText = "position:fixed;inset:0;background:rgba(0,0,0,.9);display:grid;place-items:center;z-index:9999";
  const img = document.createElement('img');
  img.src = src;
  img.alt = a.querySelector('img')?.alt || '';
  img.style.maxWidth = '90vw';
  img.style.maxHeight = '90vh';
  img.style.boxShadow = '0 20px 60px rgba(0,0,0,.6)';
  overlay.appendChild(img);
  overlay.addEventListener('click', ()=> document.body.removeChild(overlay));
  document.body.appendChild(overlay);
});

// ----- Formulario: EmailJS o fallback -----
const form = document.getElementById('contactForm');
form?.addEventListener('submit', async (e)=>{
  e.preventDefault();
  const data = Object.fromEntries(new FormData(form).entries());

  if (window.vorticeConfig?.useEmailJS) {
    // Cargar SDK si no existe
    if (!window.emailjs) {
      await new Promise((resolve, reject) => {
        const s = document.createElement('script');
        s.src = 'https://cdn.jsdelivr.net/npm/emailjs-com@3/dist/email.min.js';
        s.onload = resolve;
        s.onerror = reject;
        document.head.appendChild(s);
      });
    }
    // Init y envío
    emailjs.init(window.vorticeConfig.publicKey);
    try{
      await emailjs.send(window.vorticeConfig.serviceId, window.vorticeConfig.templateId, {
        nombre: data.nombre,
        email: data.email,
        mensaje: data.mensaje
      });
      alert('¡Gracias! Hemos recibido tu mensaje.');
      form.reset();
    } catch(err){
      console.error(err);
      alert('No se pudo enviar por EmailJS. Intenta más tarde o cambia a Apps Script.');
    }
  } else {
    // Fallback local (sin backend): muestra aviso
    alert('¡Gracias! Tu mensaje ha sido recibido. (Configura EmailJS o Apps Script en config.js para envío real)');
    form.reset();
  }
});
