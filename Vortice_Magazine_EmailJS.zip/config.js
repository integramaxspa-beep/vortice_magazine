// config.js — Variables de configuración para integraciones gratuitas
// Opción A: EmailJS (recomendado: sin backend propio)
// 1) Crea cuenta en https://www.emailjs.com/
// 2) Crea un service, un template y copia tus IDs y Public Key
// 3) Cambia useEmailJS a true y completa los campos
window.vorticeConfig = {
  useEmailJS: false,              // <- pon true para activar EmailJS
  serviceId: "YOUR_SERVICE_ID",
  templateId: "YOUR_TEMPLATE_ID",
  publicKey: "YOUR_PUBLIC_KEY"
};

// Opción B: Google Apps Script (alternativa gratis):
// - Crea un Web App que reciba POST y escribe la URL aquí (y adapta script.js para fetch)
